package movie.java;
import java.util.Scanner;//Scanner Import

public class MovieDriver {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner myObj = new Scanner(System.in);
		
		char response;
		do {//This do while loop makes it possible to add another movie
			//Task 1

			System.out.println("Enter the name of a movie: ");
			String movieName = myObj.next();//String Input name of movie
			
			System.out.println("Enter the rating of the movie: ");
			String movieRating = myObj.next();//String Input Movie rating
			
			System.out.println("\nEnter the number of tickets sold for this movie: ");
			int ticketsSold = myObj.nextInt();//Numerical Integer Input Number of Tickets Sold
			
			System.out.println("\nThe "+ movieName+ "("+movieRating+"): "+"Tickets Sold: "+ticketsSold);
	
			//Task 2
			System.out.println("\nDo you want to enter another? (Y or N)");//Goodbye message at the end of loop
	
			response = myObj.next().charAt(0);
	
		}while (response =='Y' | response == 'y');
		
		System.out.println("\nGoodbye");//Goodbye message at the end of loop
		System.exit(0);
	}
}
